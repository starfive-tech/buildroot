#pragma once

int getTestInt();
