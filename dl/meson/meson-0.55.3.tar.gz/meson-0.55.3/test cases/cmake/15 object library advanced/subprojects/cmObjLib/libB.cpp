#include "libB.hpp"
#include "libC.hpp"

std::string getZlibVers(void) {
  return getGenStr();
}
