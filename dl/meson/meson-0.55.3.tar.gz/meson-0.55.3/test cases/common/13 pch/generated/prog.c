// No includes here, they need to come from the PCH

int main(void) {
    return FOO + BAR;
}

