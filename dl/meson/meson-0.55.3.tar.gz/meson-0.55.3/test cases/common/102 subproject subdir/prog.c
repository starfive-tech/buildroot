#include <sub.h>

int main(void) {
    return sub();
}
