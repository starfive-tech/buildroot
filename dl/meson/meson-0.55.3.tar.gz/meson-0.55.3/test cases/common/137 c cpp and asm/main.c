#include <stdio.h>

int get_retval(void);

int main(void) {
  printf("C seems to be working.\n");
  return get_retval();
}
